# Setting up a new VM

## IP assign to digivault
Subnet:  27.111.33.0/28<BR>
Gateway: 27.111.33.1<BR>
Netmask: 255.255.255.240<BR>
Dns1: 119.235.28.59<BR>
Dns2: 119.235.29.59<BR>

## Configuration 4 vCPU
CPU sockets = 2<BR>
CPU Limit = 4<BR>
vCPU = 4<BR>
CPU cores (per socket)  = 2<BR>

## Configuration 2 vCPU
CPU sockets = 2<BR>
CPU Limit = 2<BR>
vCPU = 2<BR>
CPU cores (per socket)  = 1<BR>

## Configuration 6 vCPU
CPU sockets = 2
CPU Limit = 6
vCPU = 6
CPU cores (per socket)  = 3
    
# After creating from template
sudo hostnamectl set-hostname <correct host name><BR>
vi 50-cloud-init.yaml - setting the correct ip address<BR>
sudo cp 50-cloud-init.yaml /etc/netplan<BR>
sudo netplan apply<BR>

# Dashboard
Installed the dashboard using: https://docs.aws.amazon.com/eks/latest/userguide/dashboard-tutorial.html

## To get the token
kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep eks-admin | awk '{print $1}')

## To open
kubectl proxy
http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#!/login

